import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { MoodEntry, Activity, UserProfile } from '../types';
import UserProfileComponent from './UserProfile';
import MoodAnalytics from './MoodAnalytics';

const activities: Activity[] = [
  { id: '1', name: 'Exercise', icon: '🏃‍♂️', category: 'physical' },
  { id: '2', name: 'Reading', icon: '📚', category: 'mental' },
  { id: '3', name: 'Meditation', icon: '🧘‍♂️', category: 'mental' },
  { id: '4', name: 'Social', icon: '👥', category: 'social' },
  { id: '5', name: 'Work', icon: '💼', category: 'productive' },
  { id: '6', name: 'Nature', icon: '🌳', category: 'physical' },
  { id: '7', name: 'Creative', icon: '🎨', category: 'mental' },
  { id: '8', name: 'Music', icon: '🎵', category: 'mental' },
  { id: '9', name: 'Family', icon: '👨‍👩‍👧‍👦', category: 'social' },
];

const userProfile: UserProfile = {
  name: 'Vanshika',
  joinedDate: new Date(2023, 0, 1),
  preferredActivities: ['1', '2', '3']
};

const MoodTracker: React.FC = () => {
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [currentMood, setCurrentMood] = useState(3);
  const [selectedActivities, setSelectedActivities] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [energyLevel, setEnergyLevel] = useState(3);

  useEffect(() => {
    const savedEntries = localStorage.getItem('moodEntries');
    if (savedEntries) {
      setEntries(JSON.parse(savedEntries).map((entry: any) => ({
        ...entry,
        date: new Date(entry.date)
      })));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('moodEntries', JSON.stringify(entries));
  }, [entries]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newEntry: MoodEntry = {
      id: Date.now().toString(),
      date: new Date(),
      mood: currentMood,
      activities: selectedActivities,
      notes,
      energyLevel
    };
    setEntries([...entries, newEntry]);
    setCurrentMood(3);
    setSelectedActivities([]);
    setNotes('');
    setEnergyLevel(3);
  };

  const toggleActivity = (activityId: string) => {
    setSelectedActivities(prev =>
      prev.includes(activityId)
        ? prev.filter(id => id !== activityId)
        : [...prev, activityId]
    );
  };

  const getMoodEmoji = (level: number) => {
    return level === 1 ? '😢' : level === 2 ? '😕' : level === 3 ? '😐' : level === 4 ? '😊' : '😄';
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <UserProfileComponent profile={userProfile} />
      
      {entries.length > 0 && <MoodAnalytics entries={entries} />}

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">How are you feeling today?</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <label className="block text-lg font-medium text-gray-700">Mood Level</label>
            <div className="flex justify-between items-center bg-gray-50 p-4 rounded-lg">
              {[1, 2, 3, 4, 5].map((level) => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setCurrentMood(level)}
                  className={`p-4 rounded-full text-2xl transition-all ${
                    currentMood === level 
                      ? 'transform scale-125 bg-white shadow-lg' 
                      : 'hover:bg-white hover:shadow'
                  }`}
                >
                  {getMoodEmoji(level)}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-lg font-medium text-gray-700">Energy Level</label>
            <input
              type="range"
              min="1"
              max="5"
              value={energyLevel}
              onChange={(e) => setEnergyLevel(Number(e.target.value))}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-gray-600">
              <span>Low</span>
              <span>Medium</span>
              <span>High</span>
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-lg font-medium text-gray-700">Activities</label>
            <div className="grid grid-cols-3 gap-4">
              {activities.map((activity) => (
                <button
                  key={activity.id}
                  type="button"
                  onClick={() => toggleActivity(activity.id)}
                  className={`p-4 rounded-lg border transition-all ${
                    selectedActivities.includes(activity.id)
                      ? 'border-blue-500 bg-blue-50 shadow-md'
                      : 'border-gray-200 hover:border-blue-300 hover:bg-gray-50'
                  }`}
                >
                  <span className="text-2xl">{activity.icon}</span>
                  <span className="block text-sm mt-1">{activity.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-lg font-medium text-gray-700">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              rows={3}
              placeholder="How was your day? Any specific thoughts or feelings?"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Save Entry
          </button>
        </form>
      </div>

      <div className="mt-12">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Recent Entries</h3>
        <div className="space-y-4">
          {entries.map((entry) => (
            <div key={entry.id} className="bg-white p-6 rounded-lg shadow hover:shadow-md transition-shadow">
              <div className="flex justify-between items-center">
                <span className="text-gray-600 font-medium">
                  {format(entry.date, 'EEEE, MMM d, yyyy')}
                </span>
                <div className="flex items-center space-x-4">
                  <div className="text-sm text-gray-500">
                    Energy: {entry.energyLevel}/5
                  </div>
                  <span className="text-2xl">
                    {getMoodEmoji(entry.mood)}
                  </span>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {entry.activities.map((activityId) => {
                  const activity = activities.find(a => a.id === activityId);
                  return activity ? (
                    <span 
                      key={activity.id} 
                      className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-700"
                    >
                      {activity.icon} {activity.name}
                    </span>
                  ) : null;
                })}
              </div>
              {entry.notes && (
                <p className="mt-3 text-gray-600 bg-gray-50 p-3 rounded-lg">{entry.notes}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MoodTracker;