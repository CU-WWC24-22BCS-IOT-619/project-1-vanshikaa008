import React from 'react';
import { UserProfile } from '../types';
import { format } from 'date-fns';

interface UserProfileProps {
  profile: UserProfile;
}

const UserProfile: React.FC<UserProfileProps> = ({ profile }) => {
  return (
    <div className="bg-white rounded-lg shadow p-6 mb-6">
      <div className="flex items-center space-x-4">
        <div className="bg-blue-100 rounded-full p-4">
          <span className="text-2xl">👤</span>
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Welcome back, {profile.name}!</h2>
          <p className="text-gray-600">Member since {format(profile.joinedDate, 'MMMM yyyy')}</p>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;