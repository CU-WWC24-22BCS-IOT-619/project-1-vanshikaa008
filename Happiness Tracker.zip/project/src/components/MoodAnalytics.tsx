import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { MoodEntry } from '../types';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface MoodAnalyticsProps {
  entries: MoodEntry[];
}

const MoodAnalytics: React.FC<MoodAnalyticsProps> = ({ entries }) => {
  const last7Days = entries
    .slice(-7)
    .map(entry => ({
      date: format(entry.date, 'MMM d'),
      mood: entry.mood
    }));

  const data = {
    labels: last7Days.map(day => day.date),
    datasets: [
      {
        label: 'Mood Level',
        data: last7Days.map(day => day.mood),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
      }
    ]
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Your Mood Trend'
      }
    },
    scales: {
      y: {
        min: 1,
        max: 5,
        ticks: {
          stepSize: 1
        }
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 mb-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4">Mood Analytics</h3>
      <Line options={options} data={data} />
    </div>
  );
};

export default MoodAnalytics;