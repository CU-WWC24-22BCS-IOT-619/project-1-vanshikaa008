import React from 'react';
import MoodTracker from './components/MoodTracker';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4">
          <h1 className="text-3xl font-bold text-gray-900">My Happiness Journey</h1>
          <p className="text-gray-600 mt-1">Track your daily mood and activities</p>
        </div>
      </header>
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <MoodTracker />
      </main>
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto py-6 px-4 text-center text-gray-600">
          Created with ❤️ for Vanshika
        </div>
      </footer>
    </div>
  );
}

export default App;