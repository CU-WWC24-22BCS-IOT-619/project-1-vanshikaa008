export interface MoodEntry {
  id: string;
  date: Date;
  mood: number;
  activities: string[];
  notes: string;
  energyLevel?: number;
}

export interface Activity {
  id: string;
  name: string;
  icon: string;
  category: 'physical' | 'mental' | 'social' | 'productive';
}

export interface UserProfile {
  name: string;
  joinedDate: Date;
  moodGoal?: number;
  preferredActivities: string[];
}

export interface MoodAnalytics {
  averageMood: number;
  topActivities: Array<{activity: Activity, count: number}>;
  streakDays: number;
  totalEntries: number;
}